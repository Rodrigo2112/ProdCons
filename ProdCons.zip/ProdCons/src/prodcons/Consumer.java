/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prodcons;

import java.lang.System.Logger;
import java.lang.System.Logger.Level;
import java.util.concurrent.LinkedBlockingQueue;

/**
 *
 * @author Asus
 */
public class Consumer implements Runnable{
    int dato;
    LinkedBlockingQueue coda;

    public Consumer(LinkedBlockingQueue coda) {
        this.coda = coda;
    }

    @Override
    public void run() {
        try {
            Object value = coda.take();
            System.out.println("Dato letto:" + value);
        } catch (InterruptedException ex) {
            Logger.getLogger(Consumer.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
}
