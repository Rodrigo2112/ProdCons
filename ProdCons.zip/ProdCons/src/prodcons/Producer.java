/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prodcons;
import java.lang.System.Logger;
import java.lang.System.Logger.Level;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

/**
 *
 * @author Asus
 */
public class Producer implements Runnable{
    int dato;
    LinkedBlockingQueue coda;

    public Producer(LinkedBlockingQueue coda) {
        this.coda = coda;
    }

    @Override
    public void run() {
        dato = ProdCons.dato;
        ProdCons.dato++;
        try {
            coda.put(dato);
            System.out.println("Dato scritto: " + dato);
        } catch (InterruptedException ex) {
            Logger.getLogger(Produttore.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
 }

